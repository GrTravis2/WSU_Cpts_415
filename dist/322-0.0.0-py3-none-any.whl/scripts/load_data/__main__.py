"""Load data script entry point."""

from __future__ import annotations

if __name__ == "__main__":
    from scripts.load_data.load import main

    main()
