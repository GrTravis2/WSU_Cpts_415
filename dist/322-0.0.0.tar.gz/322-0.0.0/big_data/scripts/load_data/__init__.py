"""Script for loading in YouTube Data set from txt."""

from __future__ import annotations
